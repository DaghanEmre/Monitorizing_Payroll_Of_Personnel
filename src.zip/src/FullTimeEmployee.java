
public abstract class FullTimeEmployee extends Employee{
	private final static int CURRENT_YEAR = 2016;
	private final static int MIN_WORK_HOURS = 40;
	
	/*Getters Setters*/
	public static int getCurrentYear() {
		return CURRENT_YEAR;
	}

	public static int getMinWorkHours() {
		return MIN_WORK_HOURS;
	}
	
	/*Constructor*/
	public FullTimeEmployee(String name_Surname, String registration_Number, String position, int start_Year){
		super(name_Surname,registration_Number,position,start_Year);
	}

	@Override
	public float calculatePayment() {
		return 0.0f;
	}
	
	/**
	 * that function calculates the over work hours of a month
	 * that function is also a private function is created for protecting from another classes
	 * 
	 * @param maxOverWorkHours		it is the number of maximum working hours that is paying for over work
	 * @param paymentPerHour		it is the amount of payment per hour
	 * @return
	 */

	private int calculateTotalOverWorkHours(int maxOverWorkHours, int paymentPerHour){
		int totalOverWorkHours = 0;
		for(int workHours : this.getWork_Hours_Per_Week()){			
			if(workHours - MIN_WORK_HOURS < maxOverWorkHours + 1){						/*That condition controls if work hours more then 8 or not*/
				totalOverWorkHours += workHours - MIN_WORK_HOURS;
			}else{
				totalOverWorkHours += maxOverWorkHours;							/*If it is more then 8, we just add to total over worked hours 8*/
			}
		}
		return totalOverWorkHours;
	}
	
	public int getCalculateTotalOverWorkHours(int maxOverWorkHours , int paymentPerHour){
		return calculateTotalOverWorkHours(maxOverWorkHours, paymentPerHour);
	}
	
}
