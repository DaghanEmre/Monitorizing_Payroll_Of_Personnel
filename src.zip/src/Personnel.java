import java.util.ArrayList;

public abstract class Personnel {
	
	private String name_Surname;
	private String registration_Number;
	private String position;
	private int start_Year;
	private ArrayList<Integer> work_Hours_Per_Week;

	
	public abstract float calculatePayment();
	
	/**
	 * that function adds number of one week work hours to Array list
	 * 
	 * @see java.util.ArrayList
	 * 
	 * @param workHours
	 */
	public void add_Work_Hours_Per_Week(int workHours){
		work_Hours_Per_Week.add(workHours);
	}
	
	/**
	 * 
	 * @param name_Surname			name and surname of personnel
	 * @param registration_Number	id number of personnel
	 * @param position				company position of personnel
	 * @param start_Year			year that the personnel begins for this company
	 */
	/*Constructor*/
	public Personnel(String name_Surname, String registration_Number, String position, int start_Year) {
		this.name_Surname = name_Surname;
		this.registration_Number = registration_Number;
		this.position = position;
		this.start_Year = start_Year;
		work_Hours_Per_Week = new ArrayList<Integer>();
	}
	
	/*Getters Setters*/
	public ArrayList<Integer> getWork_Hours_Per_Week() {
		return work_Hours_Per_Week;
	}
	
	public String getName_Surname() {
		return name_Surname;
	}
	public void setName_Surname(String name_Surname) {
		this.name_Surname = name_Surname;
	}
	public String getRegistration_Number() {
		return registration_Number;
	}
	public void setRegistration_Number(String registration_Number) {
		this.registration_Number = registration_Number;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public int getStart_Year() {
		return start_Year;
	}
	public void setStart_Year(int start_Year) {
		this.start_Year = start_Year;
	}

}
