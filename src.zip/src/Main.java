
public class Main {

	/**
	 * 
	 * @author      Daghan Emre Aytac <daghanemreaytac@hotmail.com>
	 * @version  	1.1 		(Current version number of program)
	 * @since 		10.03.2016	(the version of the package this class was first added to)
	 */
	public static void main(String[] args) {
		String[] personnelLines = PaymentManagement.readFile(args[0]);
		String[] monitoringLines = PaymentManagement.readFile(args[1]);
		PaymentManagement.buildPersonnel(personnelLines, monitoringLines);
	}

}
