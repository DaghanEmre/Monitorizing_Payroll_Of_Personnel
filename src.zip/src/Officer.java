
public class Officer extends Personnel{
	private final static int BASE_SALARY = 1800;
	private final static float sSBenefits = (float)49/100;
	private final static int CURRENT_YEAR = 2016;
	private final static int MIN_WORK_HOURS = 40;
	
	public 	Officer(String name_Surname, String registration_Number, String position, int start_Year){
		super(name_Surname,registration_Number,position,start_Year);
	}

	/**
	 * 	that function is an override function that calculates a monthly payment of an Officer
	 */
	
	@Override
	public float calculatePayment() {
		int totalOverWorkHours = 0;
		for(int workHours : this.getWork_Hours_Per_Week()){			
			if(workHours - MIN_WORK_HOURS < 11){						/*That condition controls if work hours more then 8 or not*/
				totalOverWorkHours += workHours - MIN_WORK_HOURS;
			}else{
				totalOverWorkHours += 10;							/*If it is more then 8, we just add to total over worked hours 8*/
			}
		}
		float totalGain = (float)BASE_SALARY + (BASE_SALARY * sSBenefits)
				+ (float)(CURRENT_YEAR - this.getStart_Year())*20*4/5 + (float)totalOverWorkHours*4 ; 
		return totalGain;
	}
}
