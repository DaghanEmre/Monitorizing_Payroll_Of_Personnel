
public class Worker extends FullTimeEmployee{
	private final static int MAX_OVER_WORK_HOURS = 10;
	private final static int PAYMENT_PER_HOUR = 4;
	private final static int PAYMENT_PER_DAY = 73;
	private final static int NUMBER_OF_WORKING_DAYS_PER_MONTH = 5*4; 	/*Number of working days per week is 5, and there are 4 week in a month*/
		
	public 	Worker(String name_Surname, String registration_Number, String position, int start_Year){
		super(name_Surname,registration_Number,position,start_Year);
	}

	/**
	 * 	that function is an override function that calculates a monthly payment of a Worker
	 */
	
	@Override
	public float calculatePayment() {
		int totalOverWorkHours = super.getCalculateTotalOverWorkHours(MAX_OVER_WORK_HOURS, PAYMENT_PER_HOUR);
		float totalGain = (float)totalOverWorkHours * PAYMENT_PER_HOUR
				+ (float)PAYMENT_PER_DAY * NUMBER_OF_WORKING_DAYS_PER_MONTH
				+ (float)(super.getCurrentYear() - this.getStart_Year())*20*4/5;
		return totalGain;
	}

}
