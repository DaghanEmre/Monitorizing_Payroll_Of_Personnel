
public class Security extends Personnel{
	private final static int CURRENT_YEAR = 2016;
	private final static int NUMBER_OF_WORKING_DAYS_PER_MOUNTH = 4*6;		/*6 days of each 4 week*/
	private final static float PAYMENT_PER_HOUR = (float) 13/2;
	private final static int FOOD_TRANSFER_PAYMENT = 4+5;
	
	public 	Security(String name_Surname, String registration_Number, String position, int start_Year){
		super(name_Surname,registration_Number,position,start_Year);
	}

	/**
	 * 	that function is an override function that calculates a monthly payment of a Security
	 */
	
	@Override
	public float calculatePayment() {
		int totalWorkHours =  0;
		for(int workHours : this.getWork_Hours_Per_Week()){
			if(workHours < 30){				/*It controls if day number of each week is less then 30. If it is so,*/
													/*there is no payment*/	
			}else if(workHours > 54){				/*More then 54 hour each week, security gain just payment of 54 hour*/
				totalWorkHours += 54;
			}else{
				totalWorkHours += workHours;
			}
		}
		float totalGain = totalWorkHours*PAYMENT_PER_HOUR 
				+ (float)FOOD_TRANSFER_PAYMENT * NUMBER_OF_WORKING_DAYS_PER_MOUNTH
				+ (float)(CURRENT_YEAR - this.getStart_Year())*20*4/5;
		return totalGain;
	}

}
