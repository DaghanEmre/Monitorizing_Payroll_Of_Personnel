import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Locale;
import java.io.PrintWriter;

public class PaymentManagement {
	
	/**
	 * reading all lines of input file and adding to an arraylist
	 * 
	 * @throws IOException  If an input exception occoured
	 * @see java.io.IOException
	 * @see java.nio.file.Files
	 * @see java.nio.file.Paths
	 * 
	 * @param path		string that holds the path of target input file
	 * @return			returning an arraylist that holds lines of the input file
	 */
	
	public static String[] readFile(String path){
		try{
			int i = 0;
			int lenght = Files.readAllLines(Paths.get(path)).size();
			String[] results = new String[lenght];
			
			for (String line:Files.readAllLines(Paths.get(path))) {
				results[i++] = line;
			}
			
			return results;
			
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * That function gets the personnel's id number, and uses it to make an output file
	 * After making the output writer object, it returns in PrintWriter class
	 * 
	 * @throws IOException  If an output exception occoured
	 * @see java.io.IOException
	 * @see java.io.PrintWriter
	 * 
	 * @param registerNumber	It holds the identification number of personnel, we need that attribute to use as name of output file
	 * @return
	 */
	
	public static PrintWriter openFile(String registerNumber){
		StringBuilder value = new StringBuilder();
		value.append(registerNumber);							/*that append method using for concatenating ".txt" and registration number*/
		value.append(".txt");
		File output = new File(value.toString());
		try{
			PrintWriter outWriter = new PrintWriter(output);
			return outWriter;
		}catch(IOException e){
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * that function gets string arrays that hold the lines of personnel and monitoring files
	 * first, it splits each lines of the personnel.txt and creates a personnel object using the splitted strings
	 * it sends the string array of monitoring text file to findRightWeeklyWorkHours function and gets a string array of weekly work hours
	 * it converts the weekly work hours string arrays to integer
	 * then it adds the weekly work hours to add_Work_Hours_Per_Week Arraylist attribute of personnel class
	 * it gets the double total gain value from calculatePayment override function of related class
	 * it gets the outWriter object from openFile function of PaymentManager class and sends to writeToFile function to print an output
	 * 
	 * @see java.io.PrintWriter
	 * 
	 * @param personnelLines		a string array consists of lines of "Personnel.txt" file
	 * @param monitoringLines		a string array consists of lines of "Monitoring.txt" file
	 */
	
	public static void buildPersonnel(String[] personnelLines,String[] monitoringLines){
		for(String line : personnelLines){
			String[] attributes = line.split("\t");
			String [] workHours = findRightWeeklyWorkHours(attributes[1], monitoringLines);
			
			if(attributes[2].equals("MANAGER")){
				Personnel manager = new Manager(attributes[0], attributes[1], attributes[2], Integer.parseInt(attributes[3]));
				for(int i=1; i<workHours.length; i++){										
					manager.add_Work_Hours_Per_Week(Integer.parseInt(workHours[i]));		/*Adding each work hours of 4 weeks*/
				}
				double totalGain = manager.calculatePayment();
				
				PrintWriter outWriter = openFile(manager.getRegistration_Number());
				
				writeToFile(outWriter, manager, totalGain);
				
				outWriter.close();
				
			}else if(attributes[2].equals("WORKER")){
				Personnel worker = new Worker(attributes[0], attributes[1], attributes[2], Integer.parseInt(attributes[3]));
				for(int i=1; i<workHours.length; i++){										
					worker.add_Work_Hours_Per_Week(Integer.parseInt(workHours[i]));		/*Adding each work hours of 4 weeks*/
				}
				double totalGain = worker.calculatePayment();
				
				PrintWriter outWriter = openFile(worker.getRegistration_Number());
				
				writeToFile(outWriter, worker, totalGain);
				
				outWriter.close();

			}else if(attributes[2].equals("SECURITY")){
				Personnel security = new Security(attributes[0], attributes[1], attributes[2], Integer.parseInt(attributes[3]));
				for(int i=1; i<workHours.length; i++){										
					security.add_Work_Hours_Per_Week(Integer.parseInt(workHours[i]));		/*Adding each work hours of 4 weeks*/
				}
				double totalGain = security.calculatePayment();

				PrintWriter outWriter = openFile(security.getRegistration_Number());
				
				writeToFile(outWriter, security, totalGain);
				
				outWriter.close();
			}else if(attributes[2].equals("OFFICER")){
				Personnel officer = new Officer(attributes[0], attributes[1], attributes[2], Integer.parseInt(attributes[3]));
				for(int i=1; i<workHours.length; i++){										
					officer.add_Work_Hours_Per_Week(Integer.parseInt(workHours[i]));		/*Adding each work hours of 4 weeks*/
				}
				double totalGain = officer.calculatePayment();
				
				PrintWriter outWriter = openFile(officer.getRegistration_Number());
				
				writeToFile(outWriter, officer, totalGain);
				
				outWriter.close();
				

			}else if(attributes[2].equals("CHIEF")){
				Personnel chief = new Chief(attributes[0], attributes[1], attributes[2], Integer.parseInt(attributes[3]));
				for(int i=1; i<workHours.length; i++){										
					chief.add_Work_Hours_Per_Week(Integer.parseInt(workHours[i]));		/*Adding each work hours of 4 weeks*/
				}
				double totalGain = chief.calculatePayment();
				
				PrintWriter outWriter = openFile(chief.getRegistration_Number());
				
				writeToFile(outWriter, chief, totalGain);
				
				outWriter.close();

			}else if(attributes[2].equals("PARTTIME_EMPLOYEE")){
				Personnel partTimeEmployee = new PartTimeEmployee(attributes[0], attributes[1], attributes[2], Integer.parseInt(attributes[3]));
				for(int i=1; i<workHours.length; i++){										
					partTimeEmployee.add_Work_Hours_Per_Week(Integer.parseInt(workHours[i]));		/*Adding each work hours of 4 weeks*/
				}
				double totalGain = partTimeEmployee.calculatePayment();

				PrintWriter outWriter = openFile(partTimeEmployee.getRegistration_Number());
				
				writeToFile(outWriter, partTimeEmployee, totalGain);
				
				outWriter.close();

			}else{
				System.out.println("Wrong Personnel Position");
				System.out.println("You need to wright one of the personnel types below:");
				System.out.println("PARTTIME_EMPLOYEE, CHIEF, OFFICER, SECURITY, WORKER, or MANAGER");
			}
			
		}
		
	}
	
	/**
	 * The function generally searches for right line of "Monitoring.txt" that matches with registration number of personnel
	 * That function splits each strings of monitoringLines string array and get the first member that holds id number of personnel
	 * then it compares that string with the registration_Number that is parameter of function
	 * 
	 * @param registration_Number		It holds the identification number of personnel, we need that attribute to use as name of output file
	 * @param monitoringLines			a string array consists of lines of "Monitoring.txt" file
	 * @return
	 */
	
	public static String[] findRightWeeklyWorkHours(String registration_Number, String[] monitoringLines){
		for(String line : monitoringLines){
			String[] parts = line.split("\t");
			if(parts[0].equals(registration_Number)){
				return parts;
			}
		}
		return null;
	}
	
	/**
	 * That function prints the attributes that is asked for right output format
	 * for loop in the function controls the name and surname of personnels if they have 2 name
	 * 
	 * @see java.util.Locale
	 * @see java.io.PrintWriter
	 * 
	 * @param outWriter		a PrintWriter class object that is used for printing to file
	 * @param personnel		a Personnel class object that is expected to be printed
	 * @param totalGain		a double variable that is calculated for the total gain of personnel
	 */
	
	public static void writeToFile(PrintWriter outWriter, Personnel personnel, double totalGain){
		String[] parts = personnel.getName_Surname().split(" ");
		outWriter.print("Name : ");
		for(int i = 0; i < parts.length - 1 ; i++){					/*That code script controls if the personnel has more than*/
			if(i == parts.length -2){								/*one name. If it is so, then last word will be surname, and*/
				outWriter.println(parts[i]);						/*another words will be in name section*/
			}else{
				outWriter.print(parts[i] + " ");
			}
		}

		outWriter.println("Surname : " + parts[parts.length - 1]);	/*The last index of parts array will be surname*/
		
		outWriter.println("Registration Number : " + personnel.getRegistration_Number());
		outWriter.println("Position : " + personnel.getPosition());
		outWriter.println("Year of Start : " + personnel.getStart_Year());
		outWriter.println("Total Salary : " + String.format(Locale.ENGLISH, "%.2f", totalGain) + " TL");
	}

}
