
public class PartTimeEmployee extends Employee{
	private final static int PAYMENT_PER_HOUR = 12;
	private final static int MIN_WORK_HOURS_PER_WEEK = 10;
	private final static int MAX_WORK_HOURS_PER_WEEK = 20;
	
	public 	PartTimeEmployee(String name_Surname, String registration_Number, String position, int start_Year){
		super(name_Surname,registration_Number,position,start_Year);
	}

	/**
	 * 	that function is an override function that calculates a monthly payment of a PartTimeEmployee
	 */
	
	@Override
	public float calculatePayment() {
		int totalOverWorkHours = 0;
		for(int workHours : this.getWork_Hours_Per_Week()){
			if(workHours > MAX_WORK_HOURS_PER_WEEK){
				totalOverWorkHours += MAX_WORK_HOURS_PER_WEEK;
			}else if(workHours < MIN_WORK_HOURS_PER_WEEK){
				continue;
			}else{
				totalOverWorkHours += workHours;
			}
		}
		float totalGain = (float)totalOverWorkHours * PAYMENT_PER_HOUR;
		return totalGain;
	}

	
}
