
public abstract class Employee extends Personnel{

	@Override
	public float calculatePayment() {
		return 0.0f;
	}
	
	/*Constructor*/
	public Employee(String name_Surname, String registration_Number, String position, int start_Year) {
		super(name_Surname,registration_Number,position,start_Year);
	}

}
